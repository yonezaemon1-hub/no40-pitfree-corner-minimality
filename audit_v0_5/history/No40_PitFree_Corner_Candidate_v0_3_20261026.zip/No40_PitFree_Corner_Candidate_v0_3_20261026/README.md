# No.40 candidate v0.3 — Minimal failure of corner tests for tilt-correlated drainage

26 October 2026. Ryutaro Yonezu / Yonezu Research Lab.

**RESEARCH CANDIDATE. External AI mathematical audit of v0.2 received: PASS.
Historical novelty INCONCLUSIVE. Publication HOLD.**

Distribution v0.3 records the received review, supports isolated Python, and
extends the source comparison. The theorem/proof body and witness are unchanged.
Version 0.2 in witness/evidence JSONs identifies the audited mathematical model;
the distribution is v0.3. Both verifier function bodies remain unchanged.

The previous candidate counted routing/outlet patterns under a shared two-axis
terrain tilt. Its quadratic upper bound is an elementary consequence of line
arrangements. This revision keeps that earlier archive intact under `history/`
and makes a different, sharper statement the candidate's main result.

## Candidate result

Under the full unit D4 rectangular-grid rule
`H_(r,c)(a,b) = h_(r,c) + a*c + b*r`, choose the lowest STRICTLY lower neighbor,
with fixed row-major ties. Boundary cells obey the same rule as other cells.

1. A 4-by-3 integer terrain has the SAME TWO strict boundary sinks for the
   whole closed parameter rectangle, with no interior sink at any tilt.
2. An interior source reaches A at all four parameter-box corners, but B at
   the parameter-box center. Its exact rule is `A iff |a|+b >= 1`.
3. An analytical proof shows that a 3-by-3 full grid with the same assumptions
   cannot do this. Since an interior source requires both side lengths at
   least three, **12 cells is the exact minimum in this specified class**.

This removes the previous example's dependence on a new interior pit. It also
separates an elementary general geometric upper bound from the narrow
minimal-counterexample claim. It does NOT establish historical novelty.

## Reproduce on a local PC

Python 3.12+; standard library only; no network, API, installation, or GPU.
In Windows PowerShell after opening this extracted folder:

    py -3.12 .\check_hashes.py
    py -3.12 .\verify.py
    py -3.12 .\audit_3x3.py

Isolated execution is also supported, including from another working folder
when an absolute script path is supplied:

    py -3.12 -I .\verify.py
    py -3.12 -I .\audit_3x3.py

On another Python installation use `python` or `python3` instead of `py -3.12`.
Run hash checks first. Verification regenerates the corresponding evidence
JSON files; generation does not modify the proof or witness. Some runtime
versions may differ in random-corpus generation, so the distributed corpus
is retained for inspection. The 12-cell verification is deterministic exact
arithmetic.

`verify.py` checks both separately written routing implementations, proves
that only A and B can be sinks anywhere in the box by exact inequalities,
and checks EVERY face of the parameter arrangement (including boundary/tie
faces). The analytical 12-minimality theorem is in `PROOF.md`; it is not
replaced by the finite diagnostic corpus in `audit_3x3.py`.

## Contents for review

- `PROOF.md`: exact model, witness, induced-path lemma, and all 3-by-3 cases.
- `witness.json`: integer heights and rational parameter rectangle.
- `terrain.py`, `arrangement.py`, `verify.py`: exact witness certificate.
- `audit_3x3.py`: bounded falsification corpus over all boundary root pairs.
- `ARRANGEMENT_CERTIFICATE.md`: why every parameter face is covered.
- `PRIOR_ART.md`: checked sources, equivalence risks, and unresolved novelty.
- `SOURCE_COMPARISON.md`: source-by-source comparison and access limits.
- `AUDIT_STATUS.md`: scope, author-side results, and outstanding independent work.
- `reviews/`: the received external AI report and response to its import issue.
- `evidence/`: reproducible JSONs and logs.
- `history/`: unchanged prior candidate archive; its earlier claims and tie
  convention remain historical and do not override this revision.

One external AI mathematical review of v0.2 is recorded as a received report.
The reviewer's large-search code and raw logs have not been supplied; those
counts are not presented as author-reproduced computations. No human peer
review is claimed. The reviewer did not assess references or historical novelty.
No Windows execution of this revision is claimed without a received PC log.
This is a finite mathematical routing model, not empirical runoff validation.

Research inquiries: yonezaemon1+research@gmail.com.

Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
