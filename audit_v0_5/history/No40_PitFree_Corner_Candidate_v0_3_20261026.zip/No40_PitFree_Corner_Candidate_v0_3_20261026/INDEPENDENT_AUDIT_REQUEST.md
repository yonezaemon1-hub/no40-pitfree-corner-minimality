# Follow-up review request — distribution v0.3

The v0.2 mathematics received the external AI PASS preserved under reviews/.
This distribution changes only import handling, documentation and review/source
records. The theorem/proof body, witness and verification function bodies are
unchanged, with a revision receipt under evidence/.

For a DIFFERENTIAL review:
1. Inspect evidence/REVISION_RECEIPT.json and verify the package hashes.
2. Confirm isolated execution of verify.py and audit_3x3.py from a different
   working directory. The sibling-module path is now explicit.
3. Check that received independent-search counts are attributed rather than
   misrepresented as author reruns; no independent raw logs have been supplied.
4. Assess SOURCE_COMPARISON.md, including its explicit incomplete-text limits.

For a literature/novelty review, focus on the EXACT minimum 12 under all stated
constraints. Known graph drainage, watershed/MSF theory, generic nonconvex
outlet aggregation and the prior quadratic arrangement bound are NOT the
claimed new contribution. Check alternative node/edge encodings and whether
a known result directly yields the 3-by-3/4-by-3 distinction.

The v0.2 mathematical proof is not newly changed work requiring another full
proof audit. Large random searches need not be repeated merely because the
package version changed. Report separate verdicts for the differential changes
and for any references/novelty work actually performed.
