# Audit status — No.40 candidate distribution v0.3

26 October 2026. Mathematical model/proof body remains v0.2. Publication HOLD.

| Item | Current status / scope |
|---|---|
| MODEL / WITNESS / MINIMALITY | Received external AI review: PASS for v0.2; no mathematical changes in v0.3 |
| PARAMETER COVERAGE | Author exact 47-face certificate; reviewer reports analytical checks, 26001 rational points and six tie tests |
| External COMPUTATION verdict | PASS for ordinary execution, with isolated-import issue in v0.2 |
| Isolated-import issue | FIXED in both entry scripts; python -I from another working directory PASS |
| Formula / sink invariance | Unchanged: A iff abs(a)+b >= 1; same two strict boundary sinks throughout |
| Full parameter arrangement | 16 vertices + 23 1D faces + 8 2D cells = 47 faces |
| Routing / terminal maps | 3 / 3, unchanged |
| Author 3-by-3 diagnosis | 362 accepted terrains out of 1120 candidates; 233 unanimous-corner cases; 10028 exact faces |
| Reviewer large search | Approximately 56.7 million 3-by-3 cases, zero counterexamples, as REPORTED; candidate/accepted breakdown not supplied |
| Reviewer positive control | 44 counterexamples on 4-by-3 terrains, as REPORTED |
| Independent search code/raw logs | NOT RECEIVED |
| Reviewer REFERENCES / NOVELTY | NOT ASSESSED by that reviewer |
| Author source review | PARTIAL; see SOURCE_COMPARISON.md |
| Historical novelty | INCONCLUSIVE; exact minimum-12 match not identified within inspected material, absence not established |
| External AI mathematical review | One report received through the user; identity/runtime not specified in the pasted report |
| Human peer review | NOT PERFORMED |
| Windows execution of v0.3 | NOT RECEIVED / NOT CLAIMED |
| Author execution | Linux-side Python 3.12.14; standard library only; isolated runs now supported |
| RELEASE | HOLD retained; no public repository/DOI posting in this continuation |

The received report is preserved under reviews/. Its finite rational grid, Euler
count, and large random search are auxiliary evidence. Universal witness validity
comes from explicit inequalities and the outlet formula, with the exact
arrangement certificate; universal 12-minimality comes from the analytical
3-by-3 proof. Finite search is not substituted for either theorem.

No author receipt is fabricated for the reviewer's independent runs. Its
approximately 56.7-million count is recorded as received, without inventing a
candidate-versus-accepted breakdown or execution environment. We did not rerun
that large search.

Only the status preamble of PROOF.md changed. The mathematical body, witness,
core routing/arrangement modules, and mathematical evidence JSONs are unchanged.
The two entry scripts add explicit sibling-module resolution under isolated
Python; their function bodies are unchanged. See evidence/REVISION_RECEIPT.json.

Historical equivalence remains open across node/edge watershed encodings,
full-path definitions and parametric label partitions. Different terminology
or tie conventions alone cannot establish novelty. The exact minimum remains
confined to full unit D4 rectangles, an interior source, exactly two fixed strict
boundary sinks throughout an axis-aligned tilt box, and deterministic strict
minimum-neighbor routing.
