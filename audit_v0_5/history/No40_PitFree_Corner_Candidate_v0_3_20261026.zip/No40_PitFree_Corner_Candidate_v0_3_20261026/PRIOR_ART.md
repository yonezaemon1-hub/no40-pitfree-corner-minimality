# Prior-art disposition — updated 26 October 2026

REFERENCES: PARTIAL. HISTORICAL NOVELTY: INCONCLUSIVE.

The known background is established: steepest graph drainage, uncertain
watersheds, stable minima, node/edge watershed formulations, MSF connections and
perturbation-based segmentation uncertainty precede this candidate. Grouping
several affine route-selection regions by one outlet need not preserve
convexity; that generic failure mechanism is elementary.

The proposed residual is ONLY the exact minimum 12 within the full rectangular
D4, interior-source, two-fixed-strict-boundary-sink, shared-two-axis-tilt,
axis-aligned-box model. No matching theorem or direct derivation of that exact
minimum was identified in the inspected material. This is not an absence proof
or priority claim.

SOURCE_COMPARISON.md gives primary URLs, inspected statements, mathematical
comparisons and retrieval limits. Model differences are not proof that an
equivalent theorem is absent in another encoding.

The earlier quadratic bound uses standard line-arrangement machinery:
Steven Skiena, Maintaining Line Arrangements,
https://www.algorist.com/problems/Maintaining_Line_Arrangements.html .
That earlier bound is research history, not the proposed main contribution.

The external reviewer explicitly did not search the literature. Its mathematical
PASS does not establish novelty. Historical packages and the received report
remain under history/ and reviews/.
