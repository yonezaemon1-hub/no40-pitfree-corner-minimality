# Primary-source and equivalence comparison

26 October 2026. Bounded author-side review; not an independent novelty audit.
Technical comparisons below rely on research papers/primary author texts.
Unretrieved content is identified.

## 1. Driemel, Haverkort, Loffler, Silveira

Flow computations on imprecise terrains, Journal of Computational Geometry
4(1), 38–78 (2013), DOI 10.20382/jocg.v4i1a3.
Publisher metadata: https://jocg.org/index.php/jocg/article/view/2939 .
Author preprint read: https://arxiv.org/pdf/1111.1651
(marked arXiv:1111.1651v2, 26 September 2012).

Inspected Sections 2.1–2.2, 4.1.1 (Definition 1/Lemma 4), Theorem 2 and the
regular/stable-minimum discussion. Realizations assign heights independently
within per-vertex intervals. Flow uses maximum nonnegative slope, with multiple
ties and flat minima. The overlay combines heights from different realizations
vertex by vertex. Uncertain drainage and stable minima are established.

On unit D4 edges, unique strictly descending choices coincide with No.40's
minimum-height choice. The tie/plateau rules differ. The inspected statements
do not give the minimum-12 tilt-box result; no direct derivation was found.
Journal-PDF retrieval failed, so the final journal text was not compared in full.

Our mathematical comparison: a two-axis tilt family need not be closed under
vertexwise minimum. Relative to any baseline on a 2-by-2 patch:

| Cell | Tilt (1,-1) | Tilt (-1,1) | Vertexwise minimum |
|---|---:|---:|---:|
| (0,0) | 0 | 0 | 0 |
| (0,1) | 1 | -1 | -1 |
| (1,0) | -1 | 1 | -1 |
| (1,1) | 0 | 0 | 0 |

The last column would force a=b=-1, which gives -2 at (1,1), not 0.
This is our elementary algebra, not a theorem attributed to that paper.
It shows why its coordinatewise-construction argument cannot simply be
reused inside the restricted tilt family. It does not exclude another proof
or a differently encoded equivalent result.

## 2. Cousty, Bertrand, Najman, Couprie

Watershed cuts: minimum spanning forests and the drop of water principle,
IEEE TPAMI 31(8), 1362–1374 (2009), DOI 10.1109/TPAMI.2008.173.
Primary author-uploaded paper text:
https://www.researchgate.net/publication/26307310_Watershed_Cuts_Minimum_Spanning_Forests_and_the_Drop_of_Water_Principle
Author bibliography: https://perso.esiee.fr/~coustyj/CV.html .

Inspected the edge-weighted framework, Definitions 5 and 8, Lemma 9, Theorem 10.
Theorem 10 equates watershed cuts and cuts induced by minimum spanning forests
relative to the minima. Graph-watershed labeling and this optimality connection
are substantive existing theory, not new contributions here.

The inspected equivalence is for a weighted graph, not a minimum rectangle size
for corner-unanimity failure under shared spatial tilt. An exact node/edge
encoding may transfer results, so the different formulation does not dismiss
equivalence. No encoding-derived proof of the precise 3-by-3/4-by-3 distinction
was identified. The author's old PDF link returned 404; the author-uploaded
primary article supplied readable text.

## 3. Meyer (2012)

The steepest watershed: from graphs to images, arXiv:1204.2134.
Primary abstract read: https://arxiv.org/abs/1204.2134 .

It describes node-weighted graphs, complete downward trajectories, pruning and
adaptation to gray images. This is close conceptual background. Its full-path
criterion must not be silently equated with fixed row-major selection at a
local tie. PDF/HTML retrieval failed. No full-text exclusion of an equivalent
theorem/example is claimed for this work.

## 4. Meyer (2015)

The Waterfall Hierarchy on Weighted Graphs, ISMM 2015, LNCS 9082, 325–336,
DOI 10.1007/978-3-319-18720-4_28.
Institutional primary paper:
https://people.cmm.minesparis.psl.eu/users/marcoteg/cv/publi_pdf/MM_refs/meyer/2015_ismm_waterfall_meyer_paper.pdf

Accessible introductory sections describe flooding graphs, basin flooding,
waterfall hierarchies and an MST approach. No.40 neither fills depressions nor
constructs a hierarchy. A subsequent request for later PDF pages returned 503;
the complete paper was not reviewed. This is background, not a negative
novelty certificate.

## 5. Straehle et al. (2012)

Seeded watershed cut uncertainty estimators for guided interactive segmentation,
CVPR 2012, 765–772.
Primary proceedings Section 3.2 (printed page 767) inspected via indexed text:
https://projet.liris.cnrs.fr/imagine/pub/proceedings/CVPR2012/data/papers/097_P1B-44.pdf
Author technical-report abstract/indexed content:
https://hci.iwr.uni-heidelberg.de/sites/default/files/publications/files/1508043927/straehle_12_seeded.pdf

Section 3.2 concerns MST edge exchanges and minimal edge-weight perturbations
changing a seeded segmentation; the paper also considers uncertain weights.
Robustness, nonlocal uncertainty and perturbation diagnostics are existing
research themes. These quantities differ from a shared two-axis height-tilt
family and a smallest rectangle for corner failure. No reduction of the exact
No.40 minimum to the inspected statements was identified. Direct PDFs timed
out; these inspected indexed sections/abstract are not a full-paper comparison.

## 6. What remains after comparison

| Claim | Disposition |
|---|---|
| Steepest graph drainage | Known model family |
| Uncertain drainage and segmentation | Known research topics |
| Generic failure of convexity after outlet aggregation | Elementary mechanism |
| Earlier quadratic arrangement bound | Standard machinery |
| Exact No.40 minimum 12 under all stated constraints | Not matched in inspected sources; INCONCLUSIVE |
| Historical first discovery | Not claimed |

Search vocabulary included imprecise terrains, correlated elevation errors,
shared/affine tilt, parametric/kinetic drainage, watershed cuts, seeded
segmentation, minimum spanning forests, downward/full-path comparisons,
corner/vertex testing, fixed sinks and 3-by-3/4-by-3 examples. Both search
engines were used. Sparse/irrelevant exact-phrase results are weak negative
evidence. Citation chaining, complete texts listed above and exact alternative
encodings remain gaps. Release remains HOLD.
