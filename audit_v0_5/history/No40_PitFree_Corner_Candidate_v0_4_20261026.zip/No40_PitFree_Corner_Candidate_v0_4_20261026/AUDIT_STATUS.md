# Audit status — No.40 candidate distribution v0.4

26 October 2026. Mathematical model/proof body remains v0.2. Publication HOLD.

| Item | Current status / scope |
|---|---|
| MODEL / WITNESS / MINIMALITY | External AI PASS reported for v0.2; theorem unchanged |
| v0.3 differential review | User-supplied follow-up reports PASS for import fix, byte comparisons and 25 hashes |
| Parameter coverage | Author exact certificate: 16 vertices + 23 1D faces + 8 2D cells; 3 routing / 3 terminal maps |
| Formula / sink invariance | A iff abs(a)+b >= 1; exactly the same two strict boundary sinks throughout |
| Existing entry scripts | Unchanged from v0.3; isolated execution already verified from another folder |
| Author 3-by-3 diagnosis | 1120 candidate terrains; 362 accepted; 233 unanimous cases; 10028 exact faces |
| Reviewer large search | Approx. 56.7 million 3-by-3 cases, zero counterexamples; reviewer report ONLY |
| Reviewer positive control | 44 counterexamples on 4-by-3 terrains; reviewer report ONLY |
| Independent search code/raw logs | NOT RECEIVED; candidate/accepted breakdown and runtime unspecified |
| Driemel final journal text | OBTAINED: 41-page publisher PDF; targeted passages checked; hash recorded |
| Rooted-MSF / watershed encoding | ESTABLISHED author-side with exact tie treatment; MSF_EQUIVALENCE.md |
| New finite MSF cross-check | All 3255 rooted forests at 47 representatives; 152985 exact cost comparisons; unique minimizers agree |
| Augmentations | Common-super-root MST agrees; separate pendants preserve two regional edge minima |
| New reduction independent review | NOT YET RECEIVED |
| Author prior-art review | EXTENDED targeted primary-source review; broader search remains partial |
| Exact minimum-12 prior equivalence | No match/direct derivation identified in inspected material; INCONCLUSIVE |
| External novelty audit | NOT PERFORMED in the received reports |
| External AI review | One v0.2 report and one v0.3 follow-up supplied by user; not two independent mathematical audits |
| Human peer review | NOT PERFORMED |
| Windows execution of v0.4 | NOT RECEIVED / NOT CLAIMED |
| Author execution | Linux-side Python 3.12.14, standard library only |
| RELEASE | HOLD retained; no public repository, DOI or external message sent |

The two concrete v0.3 literature questions have author-side answers: the final
Driemel PDF is available, and the exact deterministic forest has a known MSF
encoding. These do not imply a historical novelty PASS for the remaining
constrained minimum. The new reduction applies standard cut properties and
is not proposed as a new algorithm. The main proof was not rewritten.

Universal witness validity rests on inequalities/outlet formula and the exact
arrangement certificate. Universal 12-minimality rests on the analytical
3-by-3 proof. The new forest enumeration is an additional finite oracle;
universal MSF equivalence rests on the cut-property argument. Finite point
counts and Euler consistency alone do not replace any of these arguments.

The received reviewer search counts retain explicit attribution. No author
receipt is fabricated for those runs. Only the editorial version note in
PROOF.md changed; the mathematical body and existing executables/evidence
are byte-identical to v0.3. See evidence/REVISION_RECEIPT.json.
