# Focused follow-up review request — distribution v0.4

The v0.2 mathematics and v0.3 differential changes have received the reported
AI PASS records under reviews/. Main proof body, witness, existing executables
and their JSON evidence are unchanged. This is not a request to repeat the
large random search or re-audit unchanged mathematics merely for a new version.

Review the NEW author-side equivalence/source work:

1. Check MSF_EQUIVALENCE.md: minimum-neighbor edge weight, symbolic rank ties,
   strict-descent forest, singleton cuts, unique augmented MST, and rooted-MSF
   correspondence. Does each claim hold on all parameters, including ties?
2. Check the distinction between a common-super-root MST device, arbitrary
   vertex markers and TWO separate regional edge minima via pendant leaves.
   Confirm no unjustified uniform-epsilon replacement of lexicographic weights.
3. Run audit_msf_equivalence.py. It enumerates every feasible rooted forest of
   the witness and compares exact costs at all 47 face representatives. This
   is a finite oracle, not the continuum proof or a new minimality proof.
4. Inspect the final Driemel source URL/hash/page anchors and the primary
   Allene/Cousty statements. Check the direction of the seeded-watershed
   implication and manuscript-specific theorem numbering.
5. Assess ONLY the residual novelty candidate: exact minimum 12 under all
   original constraints. Does an identified prior theorem/example directly
   give the 3-by-3 obstruction and 4-by-3 example? Supply an explicit mapping
   if it does. Known MSF membership by itself does not supply a grid-size bound.

Check hashes before generating evidence. The revision receipt records what
is unchanged from the exact v0.3 ZIP preserved under history/. Keep verdicts
separate for the new reduction, source comparison and historical novelty.
No independent novelty PASS is claimed in this distribution.
