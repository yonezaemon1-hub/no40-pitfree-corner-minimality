# No.40 candidate v0.4 — Minimal failure of corner tests for tilt-correlated drainage

26 October 2026. Ryutaro Yonezu / Yonezu Research Lab.

**RESEARCH CANDIDATE. External AI mathematical PASS reported for v0.2;
v0.3 differential PASS reported. Historical novelty INCONCLUSIVE.
Publication HOLD.**

Distribution v0.4 advances the prior-art audit. The final Driemel journal PDF
was obtained, and an exact encoding in the KNOWN rooted-MSF / watershed-cut
framework is supplied with a proof and a finite exhaustive witness check.
The minimum-12 proof body, witness, existing routing/arrangement code,
verifier scripts and their mathematical evidence JSONs are unchanged from
v0.3. Version 0.2 inside witness/evidence identifies the audited model.

## Candidate result

Under the full unit D4 rectangular-grid rule
H_(r,c)(a,b) = h_(r,c) + a*c + b*r, choose the lowest STRICTLY lower neighbor,
with fixed row-major ties. Boundary cells obey the same rule as other cells.

1. A 4-by-3 integer terrain has the SAME TWO strict boundary sinks for the
   whole closed parameter rectangle, with no interior sink at any tilt.
2. An interior source reaches A at all four parameter-box corners, but B at
   the center. Its exact rule is A iff |a|+b >= 1.
3. An analytical proof excludes 3-by-3 grids with the same assumptions.
   An interior source requires both side lengths at least three, so
   **12 cells is the exact minimum within this specified class**.

The general drainage/forest mechanism and nonconvexity after source-label
aggregation are NOT proposed as new. The sole residual candidate contribution
is this constrained exact minimum. No historical priority claim is made.

## Reproduce on a local PC

Python 3.12+; standard library only; no network, API, installation or GPU.
In Windows PowerShell, from this extracted folder:

    py -3.12 -I .\check_hashes.py
    py -3.12 -I .\verify.py
    py -3.12 -I .\audit_3x3.py
    py -3.12 -I .\audit_msf_equivalence.py

Use python or python3 on other installations. Isolated execution from another
working folder is supported when an absolute script path is supplied. Run
hash checks BEFORE regenerating evidence JSONs. The exact witness and MSF
checks are deterministic; the finite 3-by-3 corpus is retained for inspection.

verify.py checks two separately written routing implementations, uniform sink
inequalities and ALL 47 arrangement faces, including boundary/tie faces.
audit_3x3.py is auxiliary finite diagnosis, not the universal minimum proof.
audit_msf_equivalence.py enumerates all 3,255 feasible rooted forests and
compares their exact costs at each of 47 representatives, alongside Kruskal
and augmented constructions. Universal encoding rests on its cut-property
proof; representative checks alone do not prove continuum equivalence.

## Contents for review

- PROOF.md: exact model, witness and analytical 3-by-3 obstruction.
- witness.json, terrain.py, arrangement.py, verify.py: original exact certificate.
- audit_3x3.py: bounded finite diagnostic corpus.
- ARRANGEMENT_CERTIFICATE.md: parameter-face coverage argument.
- MSF_EQUIVALENCE.md, audit_msf_equivalence.py: NEW known-framework reduction
  and independent combinatorial optimization oracle for the witness.
- SOURCE_COMPARISON.md, PRIOR_ART.md: source results, access limits and disposition.
- AUDIT_STATUS.md: author and received-review evidence, distinguished explicitly.
- INDEPENDENT_AUDIT_REQUEST.md: focused review of new equivalence/source work.
- reviews/: user-supplied external AI mathematical report and v0.3 follow-up.
- evidence/: JSONs, captured logs, source receipts and revision receipt.
- history/: prior archives, including the exact audited v0.3 ZIP.

The new MSF argument and historical comparison are author-side work, not a
second independent novelty PASS. The reviewer's large-search source code and
raw logs have not been received or reproduced. No human peer review or
Windows execution of this revision is claimed. This is a mathematical routing
model, not empirical runoff validation. No third-party paper is redistributed.

Research inquiries: yonezaemon1+research@gmail.com.

Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
