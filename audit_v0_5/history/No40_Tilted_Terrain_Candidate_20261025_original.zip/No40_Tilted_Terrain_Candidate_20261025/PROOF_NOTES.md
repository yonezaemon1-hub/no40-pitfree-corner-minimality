# Proof notes — exact scope and falsification targets

## Definition of the D4 rule

Let V be a finite rectangular grid, N = |V|. Coordinates v=(r,c) are integral. Let H_v(a,b) = h_v + ac + br. Each v chooses a neighbor u with minimum H_u among neighbors strictly below H_v, if any; otherwise v becomes a sink. Equal neighbor heights are resolved by a fixed total order independent of (a,b). This choice is equivalent to selecting steepest descent on 4-neighbor unit-grid edges, with the no-descent outcome counted as a sink. Edges strictly decrease H, so no cycles and every vertex has one terminal sink.

## Upper bound O(N^2)

For each cell v, the only values relevant to the routing decision are H_v and H_u for up to four neighbors u. The ordering of these <=5 affine functions is constant until a pair has equal value. Per cell there are <= choose(5,2)=10 such equality equations in (a,b), all genuine lines because the coordinates of distinct compared vertices differ. Thus there are <=10N distinct lines over the whole grid, perhaps fewer. A planar arrangement of L lines has O(L^2) total cells of dimensions 0,1,2. On each arrangement face, all strict comparisons and equalities are fixed; the tie-breaker is fixed; hence every cell's chosen outgoing arc is fixed. The full routing map is fixed, so its terminal sink map is fixed. Therefore at most O(N^2) maps, even including parameter-boundary tie values. Intersection with any fixed rectangle cannot increase the asymptotic count.

Remark: A coarse numerical grid in (a,b) is *not* a proof; parameter arrangements are exhaustive in exact arithmetic. The formula does not cover continuous flow through triangular terrain faces, depression filling, or dynamic erosion.

## Lower bound Omega(N^2)

For every k>=1, make a 3 x (10k) rectangular grid. The baseline height is 100 in all cells except the following 2k gadgets. Gadget j has center (row 1, col x_j=5j+2), height 20. Set t_j = -3/5 + 6*((j mod k)+1)/(5*(k+1)); t_j in (-3/5, 3/5), and for each of the first k (A-type) gadgets, make center's West and East neighbors have heights -t_j and +t_j respectively; center's North and South neighbors remain at 100. In the other k (B-type) gadgets, assign -t_j and +t_j to North and South instead, retaining high West and East neighbors. All gadgets are spaced by five columns.

For all a,b in (-1,1):

- Each A-type center chooses West iff `a > -t_j`, otherwise East, except on the equality line where the tie-breaker governs. Indeed corrected local heights relative to center are `-t_j-a` West, `+t_j+a` East; both are far below the center at height 20, while North/South remain near 100.
- Each B-type center chooses North iff `b > -t_j`, otherwise South; analogous calculation. 
- Each selected low neighbor has other neighbors of baseline height >=20, so it remains a strict sink under |a|,|b|<1. Therefore distinct A/B choices correspond to distinct terminal sinks for their central cells.
- Each set of k distinct thresholds divides (-1,1) into k+1 open intervals. The k A decisions depend only on a and the k B decisions depend only on b. Every pair of intervals is nonempty and produces a unique joint terminal-sink signature.

Hence `(k+1)^2` distinct sink maps on `N=30k` cells, giving Omega(N^2) worst-case growth. Combined with O(N^2) yields Theta(N^2) on the family of rectangular grids; padding can extend bounds to intermediate permitted cell counts.

## 7 x 7 same-outlet-at-corners counterexample

Let (r,c) range 0..6. Set h_(r,c) = 20(r+c)-500, except h_(3,3)=0 and h of its four D4 neighbors =1. Source s=(3,3). Domain a,b in [-2,2]. At (a,b)=(0,0), all s neighbors have height 1 > 0, so s itself is the sink. At each of the four box corners, one or more s neighbors is lower by at least one; the downhill path from the chosen neighbor reaches the ordinary low-height background and terminates at (0,0). The latter four path results are checked exactly in verify_no40.py. This demonstrates a property-level failure of four-corner testing; the four-corner observation agrees on endpoint (0,0) yet an interior input produces a different endpoint.

## Critical questions for independent audit

- Does the O(N^2) argument handle arrangements with coincident lines, higher-order intersections and tie points? (Yes in the sketch: fewer faces, or tie fixed on lower-dimensional faces; independently check.)
- Does every selected low neighbor remain a sink for every open sample rectangle? (Witness checks exact values; verify the inequalities independently.)
- Is there a published equivalent of the Theta(N^2) statement in parametric routing or kinetic watershed analysis? Unknown. Without this audit the result should not be advertised as new.
- What changes if boundary cells are treated as mandatory external outlets, sink filling is done by Priority-Flood, or errors include non-planar spatial correlations? Requires new research; not covered.
