#!/usr/bin/env python3
"""No.40 exploratory witness; Python 3.12+, stdlib only.
Exact rational arithmetic, no external data. Research candidate, not novelty proof.
"""
from fractions import Fraction as F
from itertools import product


def d4_direction(grid, row, col, a, b):
    """Return lowest strictly downhill D4 neighbor or None (sink).
    Elevation at (r,c) = grid[r][c] + a*c + b*r.
    Fixed lexicographic tie breaking; all tests away from switching lines.
    """
    nr, nc = len(grid), len(grid[0])
    h0 = grid[row][col] + a*col + b*row
    choices = []
    for dr, dc, direction in ((-1, 0, 'N'), (0, -1, 'W'), (0, 1, 'E'), (1, 0, 'S')):
        r, c = row+dr, col+dc
        if 0 <= r < nr and 0 <= c < nc:
            hn = grid[r][c] + a*c + b*r
            if hn < h0:
                choices.append((hn, direction))
    return min(choices)[1] if choices else None


def make_gadgets(k):
    """k east/west and k north/south independent switching gadgets."""
    cols = 10*k
    terrain = [[F(100) for _ in range(cols)] for _ in range(3)]
    gadget_a, gadget_b = [], []
    for j in range(2*k):
        x = 5*j + 2
        terrain[1][x] = F(20)
        # Distinct rational switching intercepts strictly between -1 and +1.
        t = F(-3, 5) + F(6*(j % k+1), 5*(k+1))
        if j < k:
            terrain[1][x-1] = -t
            terrain[1][x+1] = +t
            gadget_a.append((x, -t))
        else:
            terrain[0][x] = -t
            terrain[2][x] = +t
            gadget_b.append((x, -t))
    return terrain, gadget_a, gadget_b


def sample_intervals(thresholds):
    vals = [F(-1)] + sorted(set(thresholds)) + [F(1)]
    return [(u+v)/2 for u, v in zip(vals, vals[1:])]


def test_corner_trap():
    grid = [[F(4),F(1),F(4)],
            [F(1),F(0),F(1)],
            [F(4),F(1),F(4)]]
    corners = [d4_direction(grid,1,1,F(a),F(b)) for a,b in product((-2,2), repeat=2)]
    middle = d4_direction(grid,1,1,F(0),F(0))
    assert all(x is not None for x in corners)
    assert middle is None
    # Exact characterization: center is a strict sink for |a|<1, |b|<1,
    # with ties at boundaries.  Verify representative points.
    for a,b in product([F(-3,2), F(-1,2), F(0), F(1,2), F(3,2)], repeat=2):
        expected_sink = abs(a)<1 and abs(b)<1
        assert (d4_direction(grid,1,1,a,b) is None) == expected_sink
    print('PASS corner-only certification is unsound: 4/4 corners drain, center (a=b=0) is a pit')



def terminal_outlet(grid, row, col, a, b):
    """Follow strict descent. Return terminal sink coordinates."""
    limit = len(grid)*len(grid[0])
    moves = {'N': (-1, 0), 'W': (0, -1), 'E': (0, 1), 'S': (1, 0)}
    for _ in range(limit):
        direction = d4_direction(grid, row, col, a, b)
        if direction is None:
            return (row, col)
        dr, dc = moves[direction]
        row, col = row+dr, col+dc
    raise AssertionError('descent path longer than number of cells')


def test_same_outlet_corner_trap():
    """Even checking the SOURCE'S terminal outlet at all box corners is unsound."""
    grid = [[F(20*(r+c)-500) for c in range(7)] for r in range(7)]
    grid[3][3] = F(0)
    for dr, dc in ((-1,0), (1,0), (0,-1), (0,1)):
        grid[3+dr][3+dc] = F(1)
    outcomes = [terminal_outlet(grid,3,3,F(a),F(b)) for a,b in product((-2,2), repeat=2)]
    baseline = terminal_outlet(grid,3,3,F(0),F(0))
    assert outcomes == [(0,0)]*4, outcomes
    assert baseline == (3,3), baseline
    print('PASS 7x7: all 4 tilt-box corners drain to the SAME outlet (0,0), interior drains to new pit (3,3)')

def test_quadratic_lower_bound():
    for k in (1,2,3,4,6,8):
        grid, ga, gb = make_gadgets(k)
        a_samples = sample_intervals([t for _,t in ga])
        b_samples = sample_intervals([t for _,t in gb])
        signatures = set()
        basin_signatures = set()
        for a,b in product(a_samples,b_samples):
            sig_a = tuple(d4_direction(grid,1,x,a,b) for x,_ in ga)
            sig_b = tuple(d4_direction(grid,1,x,a,b) for x,_ in gb)
            assert all(x in ('W','E') for x in sig_a), sig_a
            assert all(x in ('N','S') for x in sig_b), sig_b
            for (x,t),chosen in zip(ga,sig_a):
                assert chosen == ('W' if a>t else 'E')
            for (x,t),chosen in zip(gb,sig_b):
                assert chosen == ('N' if b>t else 'S')
            signatures.add((sig_a,sig_b))
            # Every preferred neighbor is an isolated stable sink at these tilt values.
            # Therefore the central cells' actual terminal-outlet identities also
            # realize all (k+1)^2 combinations, not merely their first steps.
            outlet_a = tuple(terminal_outlet(grid,1,x,a,b) for x,_ in ga)
            outlet_b = tuple(terminal_outlet(grid,1,x,a,b) for x,_ in gb)
            for (x,_),chosen,outlet in zip(ga,sig_a,outlet_a):
                assert outlet == (1,x-1 if chosen=='W' else x+1)
            for (x,_),chosen,outlet in zip(gb,sig_b,outlet_b):
                assert outlet == (0 if chosen=='N' else 2,x)
            basin_signatures.add((outlet_a,outlet_b))
        expected = (k+1)**2
        assert len(signatures)==expected
        assert len(basin_signatures)==expected
        n = len(grid)*len(grid[0])
        assert n==30*k
        print(f'PASS k={k:2d} cells={n:3d} distinct terminal-outlet + routing lower bound={len(signatures):3d} = (k+1)^2')

if __name__ == '__main__':
    test_corner_trap()
    test_same_outlet_corner_trap()
    test_quadratic_lower_bound()
    print('PASS all exploratory tests (exact Fraction arithmetic)')
