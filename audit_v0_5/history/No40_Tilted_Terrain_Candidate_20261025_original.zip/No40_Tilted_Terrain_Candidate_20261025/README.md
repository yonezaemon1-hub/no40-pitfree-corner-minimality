# No.40 exploratory candidate: Tilt-correlated terrain drainage

**Date:** 2026-10-25  
**Working English title:** *Quadratic Drainage Ambiguity under Two-Axis Correlated Elevation Tilt*  
**Status:** RESEARCH CANDIDATE, NOT A FINISHED PAPER, NOT PUBLICATION-CLEARED.

## Research question

For a finite four-neighbor (D4) grid, let a cell at integer coordinates (row r, column c) have uncertain height

    H_(r,c)(a,b) = h_(r,c) + a*c + b*r,

where `a,b` are shared real parameters restricted to a rectangle. Each cell routes water to its **lowest strictly lower** orthogonally adjacent cell (all distances equal), with deterministic tie-breaking. A cell with no lower neighbor is a sink. Following outgoing links defines its **terminal sink/outlet**. We do not fill depressions.

How many distinct complete downstream terminal-sink assignments can occur as `(a,b)` varies?

## Provisional mathematical claim

The worst-case number of distinct terminal-sink assignments over N cells is `Theta(N^2)` (and likewise for full D4 routing maps), assuming a rectangular, finite grid and the above fixed local rule. This is an exact combinatorial claim; it is **not** a claim about physical runoff or actual DEM data.

* Upper bound: compare at most 5 affine heights at each cell (self plus up to 4 neighbors), giving at most `10N` equality lines in parameter space. Arrangement of `O(N)` lines in R^2 has `O(N^2)` faces, including 2D regions, segments, and intersections. Deterministic tie-breaking makes the routing map constant on each face. Terminal-sink assignments are functions of the routing map, and therefore also `O(N^2)`.
* Lower bound: for `k` independent E/W switch cells and `k` independent N/S switch cells separated by high barriers, an explicit 3 x (10k) grid (`N=30k`) yields `(k+1)^2` distinct **terminal-sink assignments** as `a,b` each range over `(-1,1)`. Each preferred neighbor is itself a permanent sink, so the sink identity (not just the first step) differs. Thus the worst-case count grows at least quadratically along an infinite grid family.

**Caution:** Arrangement bounds are standard mathematics. This argument may be a routine corollary of established parametric-geometry results. No claim of scholarly novelty or first discovery is made.

## Counterexamples to corner-only testing

**3 x 3 grid.** Center at height 0, four neighbors at height 1, four corner cells at height 4. Over the uncertainty box `[−2,2]^2`, the center is a strict sink if `|a|<1 and |b|<1`, but not at any of the four box corners. So checking only extreme global biases cannot prove `no interior pit`.

**7 x 7 grid.** Ordinary cell heights are `20*(row+col)-500`, except center `(3,3)` has height 0 and its four D4 neighbors have height 1. Routing from `(3,3)` with each of `(a,b)=(-2,-2),(-2,2),(2,-2),(2,2)` terminates at `(0,0)`; routing with `(a,b)=(0,0)` ends at `(3,3)`. Thus even when all four parameter corners give the **same terminal outlet**, the interior can differ. Exact integer/rational witness.

## Reproduce (no network, no dependencies)

On Windows PowerShell, in this folder:

    py -3.12 .\verify_no40.py

or `python verify_no40.py`. Pure Python stdlib. All height and tilt calculations use `fractions.Fraction`. No numpy/Scipy, cloud, or API. The script tests both counterexamples and six independent-gadget sizes (`k = 1,2,3,4,6,8`).

## Research gates to clear before considering No.40 a publication

1. **Independent proof audit** of the upper bound, lower-bound construction, boundary/tie convention, and the claimed lower bound for terminal-*outlet* maps.
2. **Adversarial computation**, preferably a separately written implementation of D4 routing, exact arithmetic, and automated search for minimal equal-corner/different-interior witnesses.
3. **Novelty / equivalence audit** beyond keywords. Check parametric flow networks, kinetic planar arrangements, uncertainty-aware DEM routing, and watershed robustness. Distinguish an elementary application of line arrangements from a substantial new theorem.
4. **Nontrivial residual:** analyze depression-filling or fixed known outlet boundary conditions, or seek a sharper constructive/algorithmic certification result not immediately inherited from generic line-arrangement machinery. Avoid embellishing a simple corollary.
5. **Empirical interpretation** only if using publicly available DEM and published uncertainty calibration, strictly separated from the synthetic proof.

No new kernel/runtime/factory; no patent/priority claim.

## Literature map (selected verified online references)

- Driemel, Haverkort, Loeffler, Silveira (2013): *Flow computations on imprecise terrains*, Journal of Computational Geometry. Intervals and watershed algorithms. DOI 10.20382/jocg.v4i1a3. https://jocg.org/index.php/jocg/article/view/2939
- Barnes, Lehman, Mulla (2014): *Priority-flood: An optimal depression-filling and watershed-labeling algorithm for digital elevation models*. DOI 10.1016/j.cageo.2013.04.024. https://doi.org/10.1016/j.cageo.2013.04.024
- Tarboton (1997): *A new method for the determination of flow directions and upslope areas in grid digital elevation models*. DOI 10.1029/96WR03137. https://doi.org/10.1029/96WR03137
- Hunter and Goodchild (1997): *Modeling the uncertainty of slope and aspect estimates derived from spatial databases*. DOI 10.1111/j.1538-4632.1997.tb00944.x. https://doi.org/10.1111/j.1538-4632.1997.tb00944.x
- Darnell, Tate, Brunsdon (2008): *Improving user assessment of error implications in digital elevation models* (correlated error). DOI 10.1016/j.compenvurbsys.2008.02.003. https://doi.org/10.1016/j.compenvurbsys.2008.02.003
- Xu et al. (2024): *A multi-objective optimization framework for terrain modification based on a combined hydrological and earthwork cost-benefit*. DOI 10.1016/j.jhydrol.2024.132154. https://doi.org/10.1016/j.jhydrol.2024.132154

**Audit verdict (as of 2026-10-25):** Narrow model algebra: proof sketch COMPLETE but not independent-reviewed. Computation: PASS on included synthetic witnesses. PRIOR ART / SCHOLARLY NOVELTY: INCONCLUSIVE. Publication: NOT CLEARED. The existence of a clean theorem does not establish sufficient research contribution.
