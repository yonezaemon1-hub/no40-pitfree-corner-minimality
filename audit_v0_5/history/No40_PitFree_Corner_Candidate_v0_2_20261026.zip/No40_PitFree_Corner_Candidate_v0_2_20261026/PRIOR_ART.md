# Prior-art and mathematical-equivalence review

Review date: 26 October 2026. Historical novelty: INCONCLUSIVE.

## 1. Sources directly checked during this continuation

**Driemel, Haverkort, Loffler, Silveira, Flow computations on imprecise terrains.**
Journal of Computational Geometry 4(1), 38–78 (2013), DOI
10.20382/jocg.v4i1a3. Primary author preprint:
https://arxiv.org/abs/1111.1651 and https://arxiv.org/pdf/1111.1651 .
Author bibliography confirming the journal metadata:
https://webspace.science.uu.nl/~loffl001/publications/html/Flow_Computations_on_Imprecise_Terrains

The preprint's definitions and relevant network-model sections were inspected.
It assigns a separate allowed elevation interval to each vertex. Its network
rule uses steepest descent and treats ties/flat minima differently from this
candidate. It studies potential/persistent watersheds and stable minima. That
work is close background; robust watershed analysis and stable sinks are not
new concepts. The candidate instead restricts realizations to a shared affine
two-parameter tilt family and deterministic strict D4 descent. No theorem
matching the candidate's exact 12-cell minimum was identified in the inspected
material. This is not proof of nonexistence in that paper or the wider literature.

**Steven Skiena, Maintaining Line Arrangements, Stony Brook Algorithm Repository.**
https://www.algorist.com/problems/Maintaining_Line_Arrangements.html

The author's description explicitly uses arrangement cells to keep linear
constraint truth values fixed. Thus the earlier candidate's O(N^2) line-
arrangement upper bound is standard machinery, not an independent novelty claim.

## 2. Equivalence risks that must be stated

- Each local routing choice is an argmin of affine functions. Fixing a whole
  route imposes affine inequalities. Grouping several routes by their common
  terminal sink forms a union of such regions, which need not be convex.
  Therefore failure of a generic vertex-only test is unsurprising from
  piecewise-linear decision geometry. It must not be advertised as a new
  general robustness principle.
- The witness source compares `1-a`, `1+a`, and `b`; the absolute-value decision
  boundary is elementary. The potential residual is the realization with
  unchanged boundary sinks and the proof that a full smaller rectangle cannot
  realize this behavior under the same constraints.
- The induced-path observation and the convexity of fixed routes are elementary
  tools. No priority is claimed for either.
- The previous Theta(N^2) pattern count, its separated switches, and new-pit
  corner examples are retained only as research history, not promoted as the
  main new contribution of this revision.

## 3. Search coverage and limits

Both available search engines were used. Query families included correlated
terrain/elevation errors; imprecise terrain and watershed algorithms; parametric
and kinetic routing; affine perturbations of drainage; corner/vertex testing;
fixed two-sink and pit-free examples; induced paths of greedy descent.
The exact 12-cell claim was not located. Many precise phrase queries returned
irrelevant or sparse results. This is limited recall, not strong negative
evidence. Generic optimization, image-watershed, and computational-geometry
terminology may conceal an equivalent result.

The journal website returned redirect errors during this run. The author
preprint was readable; a byte-level journal/preprint comparison was not done.
The final paper's full theorem-by-theorem comparison, further image-watershed
literature, and an external novelty assessment remain open.

## 4. Current disposition

The model-specific minimality statement has an explicit analytical proof and
an exact 12-cell witness. It is a research candidate for independent audit.
Neither historical novelty nor publication clearance is established. Finding
an equivalent published minimum would remove its proposed novelty; the record
should then be retained as known-result/FAIL history rather than relabeled as
a new discovery.
