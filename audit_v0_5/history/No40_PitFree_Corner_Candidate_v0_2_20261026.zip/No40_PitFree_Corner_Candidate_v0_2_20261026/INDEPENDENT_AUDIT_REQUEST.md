# Independent review request

Please audit this candidate adversarially. Do not assume the prose or generated
evidence is correct. The main claim is NOT the previous quadratic arrangement
bound: it is the exact minimum of 12 cells for the narrowly defined failure of
four-corner outlet unanimity with two fixed strict boundary sinks.

1. Read PROOF.md Section 1 and reproduce the 4-by-3 witness from witness.json.
2. Run check_hashes.py BEFORE regenerating outputs, then verify.py and
   audit_3x3.py. The latter is a finite falsification corpus only.
3. Independently check the inequalities ensuring the exact same two boundary
   sinks for all tilts, and derive the source-outlet formula including ties.
4. Inspect the proof of the universal 3-by-3 theorem, especially the complete
   placement case split and the adjacent-corner argument with fixed ties.
5. Find the smallest counterexample if any hypothesis was omitted; distinguish
   changing sinks, three sinks, absorbing boundaries, and nonrectangular grids.
6. Review literature and mathematical equivalence separately from correctness.
   The generic nonconvex-aggregation mechanism is not claimed as new.

Report separate verdicts for MODEL, WITNESS, PARAMETER COVERAGE, MINIMALITY,
COMPUTATION, REFERENCES, NOVELTY and RELEASE. State exactly what you reran,
what is finite evidence only, and whether independent code/raw logs are available.

No priority claim, empirical runoff claim, human peer-review claim, or broader
model-minimum claim is authorized by this packet.
