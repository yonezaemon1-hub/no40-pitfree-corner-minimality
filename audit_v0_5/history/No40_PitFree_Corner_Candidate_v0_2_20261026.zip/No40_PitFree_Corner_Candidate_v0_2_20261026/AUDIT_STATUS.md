# Audit status — No.40 candidate v0.2

26 October 2026. Not cleared for publication.

| Item | Current status / scope |
|---|---|
| Model and domain | Explicit full unit D4 grid, strict descent, fixed row-major ties; normal boundary rule |
| 12-cell witness | AUTHOR-SIDE EXACT PASS |
| Sink invariance | EXACT PASS for the entire closed box; same two strict boundary sinks |
| Source-outlet formula | EXACT PASS: A iff abs(a)+b >= 1 |
| Full parameter coverage | 16 vertices, 23 1D faces, 8 2D cells = 47 faces |
| Separate implementations | Global-height DP and local-drop walks agree at all 12 vertices on every face |
| Distinct full routing / terminal maps for witness | 3 / 3, including tie parameters |
| Universal 3-by-3 theorem | ANALYTICAL AUTHOR PROOF COMPLETE; external independent audit pending |
| Exact minimum 12 | Follows from the analytical 3-by-3 proof and 4-by-3 witness, within the stated class |
| Bounded 3-by-3 falsification | PASS on 362 accepted terrains out of 1120 candidates; all 28 boundary-root pairs considered; 233 unanimous-corner cases; 10028 exact faces |
| What finite diagnosis proves | Only the retained corpus and its exact parameter faces; not all real terrain heights |
| Source review | PRIMARY BACKGROUND CHECKED; journal/preprint and wider equivalence comparisons incomplete |
| Historical novelty | INCONCLUSIVE |
| Human peer review | NOT PERFORMED |
| External independent AI proof review of v0.2 | NOT PERFORMED |
| Windows execution of v0.2 | NOT RECEIVED / NOT CLAIMED |
| Author execution | Linux-side Python 3.12.14; fractions.Fraction; standard library only |
| Publication | HOLD: candidate package for independent review, no repository/DOI publication in this step |

## Specific vulnerabilities to examine

1. The minimum-neighbor induced-path argument must hold with strict descent
   and all fixed tie orders, not just with generic heights.
2. On a 3-by-3 grid, a nonterminal corner forces the path to a different
   neighbor of the source; verify that this indeed contradicts the lemma.
3. In Section 5.2, confirm every possible first-step outlet label for each
   placement of the second sink. The proof relies on ONLY A and B being sinks
   throughout the entire parameter rectangle.
4. For adjacent corner sinks, check both monotonicity in one tilt coordinate
   and the at-most-one-switch argument in the other; include equality cases.
5. The minimum 12 must not be extended to square boxes, arbitrary graphs,
   D8, missing grid edges, additional or changing sinks, or absorbing all
   boundary cells. The displayed box has unequal side lengths.
6. The mechanism of a nonconvex union of affine routing cells is elementary.
   Search for an equivalent model-specific minimum before making a novelty claim.

This is an author-side package. Two code implementations are a cross-check,
not an external independent reviewer, a formal proof assistant, or PC receipt.
